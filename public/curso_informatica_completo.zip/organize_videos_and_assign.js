import fs from 'fs';
import path from 'path';

const ROOT = process.cwd();
const DATA_DIR = path.join(ROOT, '.server_data');
const VIDEOS_DIR = path.join(DATA_DIR, 'videos');
const DB_FILE = path.join(DATA_DIR, 'database.json');

function safeName(name) {
  return Date.now() + '_' + name.replace(/[^a-zA-Z0-9._-]/g, '_');
}

async function main() {
  if (!fs.existsSync(VIDEOS_DIR)) fs.mkdirSync(VIDEOS_DIR, { recursive: true });
  const allMp4 = [];
  function walk(dir) {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const e of entries) {
      const full = path.join(dir, e.name);
      if (full.includes(path.join('.', 'server_data')) || full.includes('.server_data')) continue;
      if (e.isDirectory()) walk(full);
      else if (e.isFile() && e.name.toLowerCase().endsWith('.mp4')) {
        allMp4.push(full);
      }
    }
  }
  walk(ROOT);

  console.log('Found mp4 files:', allMp4);
  const copied = [];
  for (const f of allMp4) {
    const base = path.basename(f);
    const destName = safeName(base);
    const dest = path.join(VIDEOS_DIR, destName);
    fs.copyFileSync(f, dest);
    copied.push(destName);
    console.log('Copied', f, '->', dest);
  }

  if (!fs.existsSync(DB_FILE)) {
    console.error('Database file not found:', DB_FILE);
    process.exit(1);
  }

  const raw = fs.readFileSync(DB_FILE, 'utf-8');
  const db = JSON.parse(raw);

  // Assign copied files to lessons that have empty videoUrl
  let assigned = 0;
  let copyIdx = 0;
  for (let i = 0; i < db.lessons.length && copyIdx < copied.length; i++) {
    const lesson = db.lessons[i];
    if (!lesson.videoUrl || lesson.videoUrl.trim() === '') {
      const filename = copied[copyIdx++];
      lesson.videoUrl = `/videos/${filename}`;
      lesson.videoType = 'mp4';
      assigned++;
      console.log('Assigned', filename, 'to day', lesson.day);
    }
  }

  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
  console.log(`Done. Copied ${copied.length} files, assigned ${assigned} to lessons.`);
}

main().catch((e) => { console.error(e); process.exit(1); });
