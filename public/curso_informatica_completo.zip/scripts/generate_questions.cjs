const fs = require('fs');
const path = require('path');
const dbPath = path.join(process.cwd(), '.server_data', 'database.json');
const raw = fs.readFileSync(dbPath, 'utf8');
const db = JSON.parse(raw);

for (let day = 1; day <= 3; day++) {
  const lesson = db.lessons.find(l => l.day === day);
  if (!lesson) continue;
  lesson.questions = [];
  if (Array.isArray(lesson.videos)) {
    lesson.videos.forEach((v, vi) => {
      for (let q = 1; q <= 10; q++) {
        const qid = `d${day}_v${vi+1}_q${q}`;
        lesson.questions.push({
          id: qid,
          question: `Pergunta ${q} do vídeo ${vi+1} (Dia ${day}) - conceito importante`,
          options: [`Alternativa A`, `Alternativa B`, `Alternativa C`, `Alternativa D`],
          correctIndex: 0,
          explanation: `Explicação para a pergunta ${q} do vídeo ${vi+1} do Dia ${day}.`
        });
      }
    });
  }
}

fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
console.log('Generated questions for days 1-3');
