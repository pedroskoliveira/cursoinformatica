const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const SRC = path.join(ROOT, '.server_data', 'videos');
const DST = path.join(ROOT, '.server_data', 'mdia');
const DB = path.join(ROOT, '.server_data', 'database.json');

function ensureDir(p){ if(!fs.existsSync(p)) fs.mkdirSync(p,{recursive:true}); }
function readDB(){ return JSON.parse(fs.readFileSync(DB,'utf8')); }
function writeDB(obj){ fs.writeFileSync(DB, JSON.stringify(obj,null,2),'utf8'); }

ensureDir(DST);
if(!fs.existsSync(SRC)){
  console.error('Source videos folder not found:', SRC);
  process.exit(2);
}
const files = fs.readdirSync(SRC).filter(f=>f.toLowerCase().endsWith('.mp4')).sort();
if(files.length < 15){ console.warn('Warning: less than 15 mp4s found, will reuse files.'); }
// ensure 15
const wanted = 15;
const picked = [];
for(let i=0;i<wanted;i++) picked.push(files[i % files.length]);
// copy
for(const fname of picked){
  const s = path.join(SRC,fname);
  const d = path.join(DST,fname);
  if(!fs.existsSync(d)) fs.copyFileSync(s,d);
}

const db = readDB();
for(let day=1; day<=3; day++){
  const lesson = db.lessons.find(l=>l.day===day);
  if(!lesson) continue;
  const start = (day-1)*5;
  const vids = [];
  for(let i=0;i<5;i++){
    const index = start + i;
    const fname = picked[index];
    const id = `d${day}_v${i+1}`;
    vids.push({ id, url: `/mdia/${fname}`, videoType: 'mp4', durationSeconds: null, title: `Aula ${start+i+1}` });
    // create 10 questions for this video
    const qbase = `${id}`;
    const qlist = [];
    for(let q=1;q<=10;q++){
      qlist.push({
        id: `${qbase}_q${q}`,
        question: `Pergunta ${q} sobre ${vids[i] ? vids[i].title : id}`,
        options: ["Opção A","Opção B","Opção C","Opção D"],
        correctIndex: 0,
        explanation: `Resposta correta: Opção A.`
      });
    }
    // attach these questions under lesson.questions grouped per video
    if(!lesson.videoQuestions) lesson.videoQuestions = {};
    lesson.videoQuestions[id] = qlist;
  }
  lesson.videos = vids;
  // remove legacy single-video fields
  delete lesson.videoUrl; delete lesson.videoType; delete lesson.durationSeconds;
}
writeDB(db);
console.log('Copied', picked.length, 'files to .server_data/mdia and updated DB with videos and questions for days 1-3');
