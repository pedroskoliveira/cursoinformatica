import fs from 'fs';
import path from 'path';

const ROOT = process.cwd();
const VIDEOS_DIR = path.join(ROOT, '.server_data', 'videos');
const DB_FILE = path.join(ROOT, '.server_data', 'database.json');

function originalName(filename) {
  // filenames are like <timestamp>_original.mp4 — return the original part
  const parts = filename.split('_');
  if (parts.length <= 1) return filename;
  return parts.slice(1).join('_');
}

async function main() {
  if (!fs.existsSync(VIDEOS_DIR)) {
    console.error('Videos dir not found:', VIDEOS_DIR);
    process.exit(1);
  }

  const files = fs.readdirSync(VIDEOS_DIR).filter(f => f.toLowerCase().endsWith('.mp4'));
  const groups = {};
  for (const f of files) {
    const orig = originalName(f).toLowerCase();
    if (!groups[orig]) groups[orig] = [];
    groups[orig].push(f);
  }

  const kept = [];
  const removed = [];
  for (const [orig, arr] of Object.entries(groups)) {
    // sort by name and keep first (oldest-ish)
    arr.sort();
    kept.push(arr[0]);
    for (let i = 1; i < arr.length; i++) {
      const p = path.join(VIDEOS_DIR, arr[i]);
      try {
        fs.unlinkSync(p);
        removed.push(arr[i]);
      } catch (e) {
        console.error('Failed to remove', p, e);
      }
    }
  }

  console.log('Kept files:', kept);
  console.log('Removed duplicates:', removed);

  // Load DB
  if (!fs.existsSync(DB_FILE)) {
    console.error('DB file not found:', DB_FILE);
    process.exit(1);
  }
  const db = JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));

  // Map kept by original name
  const byOrig = {};
  for (const f of kept) {
    byOrig[originalName(f).toLowerCase()] = f;
  }

  // Assign by pattern aula{n}
  const assigned = [];
  const usedFiles = new Set();
  for (const lesson of db.lessons) {
    const day = lesson.day;
    // If lesson already has videoUrl and it's not empty, skip
    if (lesson.videoUrl && lesson.videoUrl.trim() !== '') continue;
    // try pattern
    const pattern = `aula${day}`;
    const match = Object.keys(byOrig).find(k => k.includes(pattern));
    if (match) {
      const fname = byOrig[match];
      // update via API
      const res = await fetch(`http://localhost:3000/api/course/day/${day}`, {
        method: 'PUT',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ videoUrl: `/videos/${fname}`, videoType: 'mp4' })
      });
      const j = await res.json();
      assigned.push({ day, file: fname, result: j.success ? 'ok' : j });
      usedFiles.add(fname);
    }
  }

  // Assign remaining kept files sequentially to remaining empty lessons
  let fileList = kept.filter(f => !usedFiles.has(f));
  fileList.sort();
  let idx = 0;
  for (const lesson of db.lessons) {
    if (lesson.videoUrl && lesson.videoUrl.trim() !== '') continue;
    if (idx >= fileList.length) break;
    const fname = fileList[idx++];
    const res = await fetch(`http://localhost:3000/api/course/day/${lesson.day}`, {
      method: 'PUT',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ videoUrl: `/videos/${fname}`, videoType: 'mp4' })
    });
    const j = await res.json();
    assigned.push({ day: lesson.day, file: fname, result: j.success ? 'ok' : j });
    usedFiles.add(fname);
  }

  console.log('Assignments:', assigned);
  console.log('Done.');
}

main().catch(e=>{ console.error(e); process.exit(1); });
