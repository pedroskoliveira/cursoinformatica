const fs = require('fs');
const path = require('path');
const DB = path.join(__dirname, '..', '.server_data', 'database.json');
if(!fs.existsSync(DB)){
  console.error('DB not found at', DB);
  process.exit(1);
}
const db = JSON.parse(fs.readFileSync(DB,'utf8'));

// Topics for videos 1..15
const topics = [
  'CPU e processador',
  'Memória RAM',
  'Armazenamento (HD/SSD)',
  'Periféricos (Teclado, Mouse, Monitor)',
  'Software e Aplicativos',
  'Sistema Operacional (Windows)',
  'Explorador de Arquivos e pastas',
  'Gerenciamento de janelas e multitarefa',
  'Teclado e atalhos essenciais',
  'Conceitos básicos da Internet',
  'Navegadores e URLs',
  'E-mail profissional e anexos',
  'Segurança digital e phishing',
  'Senhas e autenticação (2FA)',
  'Noções básicas de solução de problemas'
];

function makeQuestion(topic, n){
  // Simple generator producing 10 varied questions per topic
  const base = topic;
  const qnum = n;
  switch(n){
    case 1:
      return {
        question: `O que é ${base}?`,
        options: [
          `Uma explicação básica de ${base}`,
          'Um tipo de cabo físico',
          'Uma marca de computador',
          'Um sistema de backup automático'
        ],
        correctIndex: 0,
        explanation: `Definição: ${base}.`,
      };
    case 2:
      return {
        question: `Qual é a principal função de ${base}?`,
        options: [
          `Executar tarefas relacionadas a ${base}`,
          'Armazenar energia elétrica',
          'Imprimir documentos automaticamente',
          'Gerar imagens 3D'
        ],
        correctIndex: 0,
        explanation: `Função principal relacionada a ${base}.`
      };
    case 3:
      return {
        question: `Assinale a alternativa correta sobre ${base}:`,
        options: [
          `${base} é usado em contextos de hardware/software dependendo do tópico`,
          'É sempre algo físico e nunca lógico',
          'Serve apenas para entretenimento',
          'Não possui relação com o computador'
        ],
        correctIndex: 0,
        explanation: `Alternativa correta: ${base} tem papéis técnicos no computador.`
      };
    case 4:
      return {
        question: `Qual item abaixo está diretamente ligado a ${base}?`,
        options: [
          `${base}`,
          'Um tipo de alimento',
          'Uma peça de mobiliário',
          'Uma linguagem de literatura'
        ],
        correctIndex: 0,
        explanation: `Relação direta com ${base}.`
      };
    case 5:
      return {
        question: `Por que é importante entender ${base}?`,
        options: [
          'Para usar o computador com segurança e eficiência',
          'Para consertar a tomada de casa',
          'Para dirigir um veículo',
          'Não é importante'
        ],
        correctIndex: 0,
        explanation: `Conhecimento prático sobre ${base} ajuda no uso diário do computador.`
      };
    case 6:
      return {
        question: `Qual prática relacionada a ${base} é recomendada?`,
        options: [
          'Aplicar boas práticas e manutenção básica',
          'Ignorar atualizações e nunca aprender',
          'Desinstalar o sistema inteiro',
          'Tentar desmontar a tela do monitor semanalmente'
        ],
        correctIndex: 0,
        explanation: `Manutenção e boas práticas são recomendadas para ${base}.`
      };
    case 7:
      return {
        question: `Qual das opções é um exemplo prático de ${base}?`,
        options: [
          `Operações e tarefas que envolvem ${base}`,
          'Cortar madeira',
          'Plantio de árvores',
          'Dançar uma coreografia'
        ],
        correctIndex: 0,
        explanation: `Exemplo prático envolvendo ${base}.`
      };
    case 8:
      return {
        question: `Ao lidar com ${base}, o usuário deve:`,
        options: [
          'Seguir instruções e boas práticas de uso',
          'Ignorar avisos do sistema',
          'Formatar o PC sem motivo',
          'Compartilhar senhas publicamente'
        ],
        correctIndex: 0,
        explanation: `Boas práticas são essenciais ao lidar com ${base}.`
      };
    case 9:
      return {
        question: `Qual item NÃO se relaciona com ${base}?`,
        options: [
          'Cozinhar alimentos',
          `${base}`,
          'Operações de software/hardware (conforme o tema)',
          'Configurações e uso correto'
        ],
        correctIndex: 0,
        explanation: `Cozinhar não tem relação com ${base}.`
      };
    case 10:
      return {
        question: `Resumo: o que você aprendeu sobre ${base}?`,
        options: [
          `Noções essenciais sobre ${base}`,
          'Nada relevante',
          'Como construir um prédio',
          'Como pintar uma tela'
        ],
        correctIndex: 0,
        explanation: `Resumo didático sobre ${base}.`
      };
    default:
      return {
        question: `Pergunta sobre ${base}`,
        options: ['Opção A','Opção B','Opção C','Opção D'],
        correctIndex: 0,
        explanation: `Resposta correta: Opção A.`
      };
  }
}

// Iterate lessons and replace videoQuestions
let replaced = 0;
for(const lesson of db.lessons){
  if(!lesson.videos || !Array.isArray(lesson.videos)) continue;
  if(!lesson.videoQuestions) lesson.videoQuestions = {};
  for(let i=0;i<lesson.videos.length;i++){
    const vid = lesson.videos[i];
    const globalIndex = (() => {
      // Compute 0-based video index across days: day-1 *5 + i
      const dayNum = lesson.day || 1;
      return (Math.max(0, (dayNum-1))*5) + i;
    })();
    const topic = topics[globalIndex % topics.length] || 'Conceitos de Computador';
    const vidId = vid.id || `d${lesson.day}_v${i+1}`;
    const qarr = [];
    for(let q=1;q<=10;q++){
      const qobj = makeQuestion(topic, q);
      // Normalize id
      qobj.id = `${vidId}_q${q}`;
      qarr.push(qobj);
    }
    lesson.videoQuestions[vidId] = qarr;
    replaced++;
  }
}

fs.writeFileSync(DB, JSON.stringify(db,null,2),'utf8');
console.log('Replaced questions for', replaced, 'video slots.');
