(async ()=>{
  try {
    const res = await fetch('http://localhost:3000/api/instructor/upload-video', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ test: true })
    });
    console.log('Status:', res.status);
    console.log(await res.text());
  } catch (e) { console.error(e); process.exit(1); }
})();
