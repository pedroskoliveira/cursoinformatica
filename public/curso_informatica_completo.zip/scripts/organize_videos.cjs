const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const VIDEOS_DST = path.join(ROOT, '.server_data', 'videos');
const DB_PATH = path.join(ROOT, '.server_data', 'database.json');

function findMp4Files(dir, out = []) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const e of entries) {
    const full = path.join(dir, e.name);
    if (e.isDirectory()) {
      // skip node_modules and .server_data
      if (['node_modules', '.server_data', '.git'].includes(e.name)) continue;
      findMp4Files(full, out);
    } else if (e.isFile()) {
      if (e.name.toLowerCase().endsWith('.mp4')) out.push(full);
    }
  }
  return out;
}

function ensureDir(p) {
  if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true });
}

function sanitizeName(name) {
  return name.replace(/[^a-z0-9_.-]/gi, '_');
}

(async function main() {
  ensureDir(VIDEOS_DST);

  const found = findMp4Files(ROOT).filter(p => !p.includes(path.join(ROOT, '.server_data')));
  if (!found.length) {
    console.error('Nenhum MP4 encontrado no workspace (exceto .server_data). Coloque arquivos .mp4 na raiz ou subpastas.');
    process.exit(2);
  }

  // pick at most 15, repeat if not enough
  const needed = 15;
  const picked = [];
  for (let i = 0; i < needed; i++) {
    picked.push(found[i % found.length]);
  }

  // Copy into .server_data/videos with deterministic names
  const dstFiles = [];
  for (let i = 0; i < picked.length; i++) {
    const src = picked[i];
    const base = path.basename(src);
    const name = `${String(i + 1).padStart(2, '0')}_${sanitizeName(base)}`;
    const dst = path.join(VIDEOS_DST, name);
    if (!fs.existsSync(dst)) {
      fs.copyFileSync(src, dst);
    }
    dstFiles.push(name);
  }

  // load DB
  if (!fs.existsSync(DB_PATH)) {
    console.error('Database not found at', DB_PATH);
    process.exit(3);
  }
  const dbRaw = fs.readFileSync(DB_PATH, 'utf8');
  const db = JSON.parse(dbRaw);

  // assign to days 1..3, 5 videos each
  for (let day = 1; day <= 3; day++) {
    const lesson = db.lessons.find(l => l.day === day);
    if (!lesson) continue;
    const vids = dstFiles.slice((day - 1) * 5, day * 5).map((fname, idx) => ({
      id: `day${day}_v${idx + 1}`,
      url: `/videos/${fname}`,
      videoType: 'mp4',
      durationSeconds: null
    }));
    lesson.videos = vids;
    // clear legacy fields to prefer videos[]
    delete lesson.videoUrl;
    delete lesson.videoType;
    delete lesson.durationSeconds;
  }

  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2), 'utf8');

  console.log('Copiados', dstFiles.length, 'arquivos para .server_data/videos');
  console.log('Arquivos:', dstFiles.join(', '));
  console.log('Atualizado database.json para dias 1-3 com 5 vídeos cada.');
})();
