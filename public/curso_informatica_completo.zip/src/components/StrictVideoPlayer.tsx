import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  ShieldAlert,
  Play,
  Lock,
  Eye,
  AlertTriangle,
  RotateCcw,
  CheckCircle2,
  Clock,
  Sparkles,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { DayLesson } from '../types';

interface StrictVideoPlayerProps {
  lesson: DayLesson;
  onVideoComplete: () => void;
  onViolation: (type: 'LEFT_VIDEO' | 'SEEK_ATTEMPT' | 'PAUSE_ATTEMPT', detail: string) => void;
  onTimeUpdate: (currentTime: number, duration: number) => void;
  isUnlockedForQuiz: boolean;
}

export const StrictVideoPlayer: React.FC<StrictVideoPlayerProps> = ({
  lesson,
  onVideoComplete,
  onViolation,
  onTimeUpdate,
  isUnlockedForQuiz,
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const duration = lesson.durationSeconds || 120;
  const [hasCompleted, setHasCompleted] = useState(isUnlockedForQuiz);
  const [violationModal, setViolationModal] = useState<{
    show: boolean;
    title: string;
    message: string;
  } | null>(null);

  const [activeSlideIndex, setActiveSlideIndex] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [playerMode, setPlayerMode] = useState<'interactive' | 'youtube'>(() =>
    lesson.videoUrl && lesson.videoUrl.trim() ? 'youtube' : 'interactive'
  );

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const timerRef = useRef<any>(null);
  const maxAllowedTimeRef = useRef<number>(0);
  const isPlayingRef = useRef<boolean>(false);
  const hasCompletedRef = useRef<boolean>(hasCompleted);

  isPlayingRef.current = isPlaying;
  hasCompletedRef.current = hasCompleted;

  // Reset when lesson changes
  useEffect(() => {
    setCurrentTime(0);
    maxAllowedTimeRef.current = 0;
    setIsPlaying(false);
    setHasCompleted(isUnlockedForQuiz);
    setActiveSlideIndex(0);
    if (lesson.videoUrl && lesson.videoUrl.trim()) {
      setPlayerMode('youtube');
    } else {
      setPlayerMode('interactive');
    }
    if (timerRef.current) clearInterval(timerRef.current);
  }, [lesson.day, isUnlockedForQuiz, lesson.videoUrl]);

  // Handle violation: triggers notification, logs to server, resets to 0:00
  const triggerViolation = useCallback(
    (type: 'LEFT_VIDEO' | 'SEEK_ATTEMPT' | 'PAUSE_ATTEMPT', detail: string) => {
      // If already completed or not playing, ignore minor blurs
      if (hasCompletedRef.current || !isPlayingRef.current) {
        return;
      }

      setIsPlaying(false);
      setCurrentTime(0);
      maxAllowedTimeRef.current = 0;
      setActiveSlideIndex(0);

      if (videoRef.current) {
        videoRef.current.currentTime = 0;
        videoRef.current.pause();
      }

      setViolationModal({
        show: true,
        title: '⚠️ Violação Detectada!',
        message: `${detail} Pelas regras deste curso, o vídeo foi reiniciado para 00:00.`,
      });

      onViolation(type, detail);
    },
    [onViolation]
  );

  // RIGOROUS DETECTION: Visibility Change and Window Blur
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden' && isPlayingRef.current && !hasCompletedRef.current) {
        triggerViolation(
          'LEFT_VIDEO',
          'Você alternou de aba ou minimizou o navegador durante a exibição do vídeo.'
        );
      }
    };

    const handleWindowBlur = () => {
      if (isPlayingRef.current && !hasCompletedRef.current) {
        // Debounce slightly to prevent false alarms on internal iframe clicks
        setTimeout(() => {
          if (document.hidden && isPlayingRef.current && !hasCompletedRef.current) {
            triggerViolation(
              'LEFT_VIDEO',
              'Você saiu do foco da janela de aula.'
            );
          }
        }, 300);
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (isPlayingRef.current && !hasCompletedRef.current) {
        // Block seeking shortcuts (Space, Arrows, J, L)
        if (
          e.code === 'Space' ||
          e.code === 'ArrowRight' ||
          e.code === 'ArrowLeft' ||
          e.key === 'j' ||
          e.key === 'l'
        ) {
          e.preventDefault();
          triggerViolation(
            'SEEK_ATTEMPT',
            'Tentativa de manipular a reprodução do vídeo usando atalhos de teclado.'
          );
        }
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('blur', handleWindowBlur);
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('blur', handleWindowBlur);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [triggerViolation]);

  // Main playback loop (ticker)
  useEffect(() => {
    if (isPlaying && !hasCompleted) {
      timerRef.current = setInterval(() => {
        setCurrentTime((prev) => {
          const next = prev + 1;
          maxAllowedTimeRef.current = Math.max(maxAllowedTimeRef.current, next);

          // Update active slide based on progress
          const slidesCount = Math.max(1, lesson.summary.length);
          const slideDuration = duration / slidesCount;
          const currentSlide = Math.min(
            slidesCount - 1,
            Math.floor(next / slideDuration)
          );
          setActiveSlideIndex(currentSlide);

          onTimeUpdate(next, duration);

          if (next >= duration) {
            clearInterval(timerRef.current);
            setIsPlaying(false);
            setHasCompleted(true);
            onVideoComplete();
            return duration;
          }
          return next;
        });
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, hasCompleted, duration, lesson.summary.length, onTimeUpdate, onVideoComplete]);

  // Start Playing
  const handleStartPlay = () => {
    if (hasCompleted) return;
    setIsPlaying(true);
    if (videoRef.current) {
      videoRef.current.play().catch(() => {});
    }
  };

  // Prevent user pausing directly
  const handleUserAttemptPause = () => {
    if (!hasCompleted && isPlaying) {
      triggerViolation(
        'PAUSE_ATTEMPT',
        'Pausa não permitida. O vídeo deve ser assistido continuamente sem interrupções.'
      );
    }
  };

  const progressPercent = Math.min(100, Math.round((currentTime / duration) * 100));

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div
      id={`strict-video-container-day-${lesson.day}`}
      className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl text-slate-100 relative"
      onContextMenu={(e) => e.preventDefault()}
    >
      {/* Violation Overlay Modal */}
      {violationModal && violationModal.show && (
        <div
          id="video-violation-alert-overlay"
          className="absolute inset-0 z-50 bg-slate-950/95 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center animate-in fade-in zoom-in duration-200"
        >
          <div className="w-16 h-16 rounded-2xl bg-red-500/20 border border-red-500/40 flex items-center justify-center text-red-400 mb-4 animate-bounce">
            <AlertTriangle className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-bold text-red-400 tracking-tight mb-2">
            {violationModal.title}
          </h3>
          <p className="text-sm text-slate-300 max-w-md mb-6 leading-relaxed">
            {violationModal.message}
          </p>
          <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl text-xs text-slate-400 max-w-sm mb-6 text-left space-y-1">
            <div className="font-semibold text-slate-200">Regras de Monitoramento:</div>
            <div>• Não saia desta aba enquanto o vídeo estiver em execução.</div>
            <div>• Não minimize o navegador nem clique fora da tela.</div>
            <div>• Não tente pausar ou adiantar o conteúdo.</div>
          </div>
          <button
            id="violation-acknowledge-btn"
            type="button"
            onClick={() => {
              setViolationModal(null);
            }}
            className="flex items-center space-x-2 px-6 py-3 bg-red-600 hover:bg-red-500 text-white rounded-xl font-semibold text-sm shadow-lg shadow-red-500/25 transition-all cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Entendi, Recomeçar Vídeo (00:00)</span>
          </button>
        </div>
      )}

      {/* Top Banner: Rules & Anti-cheat Active */}
      <div className="bg-slate-950 px-4 py-2.5 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="flex items-center space-x-2 text-amber-300">
          <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
          <span className="font-semibold">Modo de Avaliação Rigorosa Ativo</span>
          <span className="hidden sm:inline text-slate-400">• Sem pausas ou avanços • Reinicia ao sair</span>
        </div>

        <div className="flex items-center space-x-3">
          {/* Player Mode Switcher */}
          <div className="flex items-center bg-slate-800/80 rounded-lg p-0.5 border border-slate-700">
            <button
              id="player-mode-interactive-btn"
              type="button"
              onClick={() => setPlayerMode('interactive')}
              className={`px-2 py-1 rounded text-[11px] font-medium transition-colors ${
                playerMode === 'interactive'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Aula Guiada Interativa
            </button>
            <button
              id="player-mode-youtube-btn"
              type="button"
              onClick={() => setPlayerMode('youtube')}
              className={`px-2 py-1 rounded text-[11px] font-medium transition-colors ${
                playerMode === 'youtube'
                  ? 'bg-red-600 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Vídeo Externo
            </button>
          </div>

          <div className="flex items-center space-x-1.5 text-slate-400">
            <Clock className="w-3.5 h-3.5" />
            <span className="font-mono text-[11px]">
              {formatTime(currentTime)} / {formatTime(duration)}
            </span>
          </div>
        </div>
      </div>

      {/* Video Screen Area */}
      <div className="relative aspect-video bg-slate-950 flex flex-col items-center justify-center overflow-hidden select-none">
        {playerMode === 'interactive' ? (
          /* Interactive Slides Player */
          <div className="w-full h-full p-6 sm:p-10 flex flex-col justify-between bg-gradient-to-br from-slate-900 via-slate-950 to-blue-950/40 relative">
            {/* Top Slide Header */}
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
              <div className="flex items-center space-x-2">
                <span className="text-xs uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-blue-500/20 text-blue-400 border border-blue-500/30">
                  Slide {activeSlideIndex + 1} de {lesson.summary.length}
                </span>
                <span className="text-xs text-slate-400 font-medium">
                  {lesson.title}
                </span>
              </div>
              <div className="flex items-center space-x-2">
                {isPlaying && (
                  <span className="flex items-center space-x-1.5 text-xs text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                    <span>Transmitindo Aula</span>
                  </span>
                )}
              </div>
            </div>

            {/* Slide Body Content */}
            <div className="my-auto py-4 max-w-2xl mx-auto text-center space-y-4">
              <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-blue-600/20 border border-blue-500/30 text-blue-400 mb-2">
                <Sparkles className="w-7 h-7 animate-pulse" />
              </div>

              <h4 className="text-lg sm:text-2xl font-bold text-white tracking-tight leading-snug">
                {lesson.summary[activeSlideIndex] || lesson.subtitle}
              </h4>

              <p className="text-xs sm:text-sm text-slate-400 max-w-xl mx-auto leading-relaxed">
                Preste atenção a cada conceito fundamental. Este conteúdo será cobrado no Quiz avaliativo deste dia com nota de corte 8.0.
              </p>

              {/* Progress dots for slides */}
              <div className="flex items-center justify-center space-x-2 pt-2">
                {lesson.summary.map((_, idx) => (
                  <div
                    key={idx}
                    className={`h-1.5 rounded-full transition-all duration-300 ${
                      idx === activeSlideIndex
                        ? 'w-8 bg-blue-500'
                        : idx < activeSlideIndex
                        ? 'w-4 bg-emerald-500/70'
                        : 'w-2 bg-slate-800'
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* Bottom Audio/Visual Wave Effect when playing */}
            <div className="border-t border-slate-800/80 pt-3 flex items-center justify-between text-xs text-slate-400">
              <div className="flex items-center space-x-1.5">
                <Volume2 className="w-4 h-4 text-blue-400" />
                <span>Áudio didático e instruções em andamento</span>
              </div>
              <div className="flex items-center space-x-1 h-3">
                {[40, 70, 30, 90, 60, 80, 45, 95, 50, 75].map((h, i) => (
                  <span
                    key={i}
                    className={`w-1 bg-blue-500 rounded-full transition-all duration-200 ${
                      isPlaying ? 'opacity-90' : 'opacity-20'
                    }`}
                    style={{ height: isPlaying ? `${h}%` : '20%' }}
                  />
                ))}
              </div>
            </div>
          </div>
        ) : (
          /* YouTube Embed Mode (with strict lock overlay) */
          lesson.videoUrl ? (
            <div className="w-full h-full relative">
              <iframe
                id={`youtube-iframe-day-${lesson.day}`}
                src={`${lesson.videoUrl}?autoplay=${isPlaying ? 1 : 0}&controls=0&disablekb=1&modestbranding=1&rel=0`}
                title={lesson.title}
                className="w-full h-full border-0 pointer-events-none"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              />
              {/* Transparent click blocker to prevent pausing or seeking on YouTube native controls */}
              <div
                id="youtube-interaction-blocker"
                className="absolute inset-0 z-20 cursor-default"
                onClick={handleUserAttemptPause}
              />
            </div>
          ) : (
            <div className="w-full h-full p-8 flex flex-col items-center justify-center text-center bg-slate-950 text-slate-300 space-y-3">
              <div className="w-14 h-14 rounded-2xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400">
                <Clock className="w-7 h-7" />
              </div>
              <h4 className="text-base font-bold text-white tracking-tight">
                Aguardando Postagem da Videoaula
              </h4>
              <p className="text-xs text-slate-400 max-w-md leading-relaxed">
                O Administrador irá cadastrar o vídeo desta aula no Painel do Admin. Você pode usar a Aula Guiada Interativa abaixo para estudar o conteúdo completo.
              </p>
              <button
                type="button"
                onClick={() => setPlayerMode('interactive')}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-xl shadow transition-colors cursor-pointer"
              >
                Ver Aula Guiada Interativa
              </button>
            </div>
          )
        )}

        {/* Initial "Iniciar Aula" Overlay */}
        {!isPlaying && !hasCompleted && (
          <div
            id="video-start-prompt-overlay"
            className="absolute inset-0 z-30 bg-slate-950/80 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center"
          >
            <button
              id="start-lesson-video-btn"
              type="button"
              onClick={handleStartPlay}
              className="group relative flex items-center justify-center w-20 h-20 rounded-full bg-blue-600 hover:bg-blue-500 text-white shadow-2xl shadow-blue-500/40 transition-transform active:scale-95 cursor-pointer mb-4"
            >
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-20 group-hover:opacity-40"></span>
              <Play className="w-8 h-8 fill-current ml-1" />
            </button>

            <h3 className="text-xl font-bold text-white tracking-tight mb-1">
              Iniciar Aula Obrigatória
            </h3>
            <p className="text-xs text-slate-400 max-w-md mb-4">
              Ao iniciar, mantenha o foco total nesta janela. Não tente pausar ou mudar de aba para evitar que o vídeo retorne ao início.
            </p>
            <span className="text-[11px] font-semibold text-amber-300/90 bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/20">
              Duração: {formatTime(duration)}
            </span>
          </div>
        )}

        {/* Completion Banner inside video */}
        {hasCompleted && (
          <div
            id="video-completed-banner"
            className="absolute inset-0 z-30 bg-emerald-950/85 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center"
          >
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 mb-3 shadow-lg shadow-emerald-500/20">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold text-white tracking-tight mb-1">
              Aula do Dia {lesson.day} Assistida!
            </h3>
            <p className="text-xs text-emerald-200/80 max-w-md mb-4">
              Você cumpriu 100% do tempo exigido desta videoaula sem interrupções. Os exercícios e o Quiz avaliativo estão liberados!
            </p>
            <span className="text-xs font-semibold bg-emerald-500 text-slate-950 px-4 py-1.5 rounded-lg shadow-sm">
              Quiz Desbloqueado com Sucesso
            </span>
          </div>
        )}
      </div>

      {/* STRICT PROGRESS BAR (READ-ONLY, UNTOUCHABLE) */}
      <div className="bg-slate-950 px-5 py-3 border-t border-slate-800">
        <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
          <div className="flex items-center space-x-2">
            <span className="font-semibold text-slate-200">
              Progresso Obrigatório:
            </span>
            <span className="text-blue-400 font-mono font-bold">
              {progressPercent}%
            </span>
          </div>
          <div className="flex items-center space-x-1 text-[11px] text-amber-400">
            <Lock className="w-3 h-3" />
            <span>Barra de avanço bloqueada contra salto</span>
          </div>
        </div>

        {/* Visual Progress Bar (Pointer events none to strictly prevent seeking) */}
        <div
          id="strict-progress-track"
          className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden relative select-none pointer-events-none"
        >
          <div
            id="strict-progress-fill"
            className="h-full bg-gradient-to-r from-blue-600 via-indigo-500 to-emerald-500 transition-all duration-300"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* Footer Info / Anti-Cheat Guidance */}
      <div className="bg-slate-900/90 p-4 border-t border-slate-800 text-xs text-slate-400 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center space-x-2">
          <Eye className="w-4 h-4 text-slate-500 shrink-0" />
          <span>
            Detector de presença e foco ativo. Não alterne de aplicativo.
          </span>
        </div>
        <div className="text-slate-300 font-medium">
          Mínimo para passar no quiz posterior:{' '}
          <strong className="text-emerald-400 font-bold">8.0 / 10</strong>
        </div>
      </div>
    </div>
  );
};
