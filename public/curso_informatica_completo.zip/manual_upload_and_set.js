import fs from 'fs';
import path from 'path';

(async ()=>{
  try {
    const src = path.join(process.cwd(), 'sample_video.mp4');
    const destDir = path.join(process.cwd(), '.server_data', 'videos');
    if (!fs.existsSync(destDir)) fs.mkdirSync(destDir, { recursive: true });
    const destName = Date.now() + '_sample_video.mp4';
    const dest = path.join(destDir, destName);
    fs.copyFileSync(src, dest);
    console.log('Copied to', dest);

    // Update lesson 1
    const videoPath = `/videos/${destName}`;
    const body = {
      title: 'Dia 1: Anatomia do Computador & Hardware Essencial (Uploaded MP4)',
      subtitle: 'Video local enviado',
      videoUrl: videoPath,
      videoType: 'mp4'
    };

    const res = await fetch('http://localhost:3000/api/course/day/1', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    const j = await res.json();
    console.log('PUT response:', JSON.stringify(j, null, 2));
  } catch (e) { console.error(e); process.exit(1); }
})();
