(async ()=>{
  try {
    const res = await fetch('http://localhost:3000/api/instructor/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: 'admin', password: 'admin' })
    });
    console.log('Status:', res.status);
    console.log(await res.text());
  } catch (e) { console.error(e); process.exit(1); }
})();
