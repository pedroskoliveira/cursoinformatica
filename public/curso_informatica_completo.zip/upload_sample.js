import fs from 'fs';

async function main() {
  try {
    const FormData = global.FormData;
    if (!FormData) {
      console.error('Global FormData não disponível neste Node.');
      process.exit(1);
    }

    const fd = new FormData();
    fd.append('video', fs.createReadStream('sample_video.mp4'));

    const res = await fetch('http://localhost:3000/api/instructor/upload-video', {
      method: 'POST',
      body: fd
    });

    const text = await res.text();
    console.log('Status:', res.status);
    console.log(text);
  } catch (err) {
    console.error('Upload failed:', err);
    process.exit(1);
  }
}

main();
