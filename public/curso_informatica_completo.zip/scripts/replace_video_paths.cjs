const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, '..', 'data', 'database.json');

function main() {
  const db = JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
  const output = [];
  (db.lessons || []).forEach((lesson) => {
    const lessonEntry = { day: lesson.day, lessonId: lesson.id, videos: [] };
    const videos = lesson.videos || (lesson.videoUrl ? [ { url: lesson.videoUrl } ] : []);
    videos.forEach((v, idx) => {
      lessonEntry.videos.push({ index: idx + 1, currentPath: v.url || v, replaceWith: 'PASTE_EXTERNAL_URL_HERE' });
    });
    output.push(lessonEntry);
  });

  const outPath = path.join(__dirname, '..', 'video_url_replacements.json');
  fs.writeFileSync(outPath, JSON.stringify(output, null, 2));
  console.log('Wrote', outPath);
}

main();
