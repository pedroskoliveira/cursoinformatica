import fs from 'fs';
import path from 'path';

const ROOT = process.cwd();
const VIDEOS_DIR = path.join(ROOT, '.server_data', 'videos');
const DB_FILE = path.join(ROOT, '.server_data', 'database.json');

async function main() {
  const files = fs.existsSync(VIDEOS_DIR) ? fs.readdirSync(VIDEOS_DIR).filter(f=>f.toLowerCase().endsWith('.mp4')) : [];
  files.sort();
  console.log('Videos found in .server_data/videos:', files);

  if (!fs.existsSync(DB_FILE)) { console.error('DB missing'); process.exit(1); }
  const db = JSON.parse(fs.readFileSync(DB_FILE,'utf-8'));

  let fileIdx = 0;
  for (let i=0;i<db.lessons.length && fileIdx<files.length;i++){
    const lesson = db.lessons[i];
    if (!lesson.videoUrl || lesson.videoUrl.trim()===''){
      const filename = files[fileIdx++];
      const videoUrl = `/videos/${filename}`;
      const body = {
        title: lesson.title,
        subtitle: lesson.subtitle,
        videoUrl,
        videoType: 'mp4'
      };

      const res = await fetch(`http://localhost:3000/api/course/day/${lesson.day}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      const j = await res.json();
      console.log('Updated day', lesson.day, '=>', j.success ? 'ok' : j);
    }
  }
  console.log('Done assigning via API.');
}

main().catch(e=>{ console.error(e); process.exit(1); });
