async function check() {
  try {
    let res = await fetch('http://localhost:3000/api/instructor/upload-video', { method: 'OPTIONS' });
    console.log('OPTIONS', res.status);
    res = await fetch('http://localhost:3000/api/instructor/upload-video', { method: 'GET' });
    console.log('GET', res.status);
    const text = await res.text();
    console.log('GET body length:', text.length);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
}

check();
