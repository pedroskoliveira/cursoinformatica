(async ()=>{
  try {
    const res = await fetch('http://localhost:3000/api/students/identify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: 'Aluno Teste 2', birthDate: '2010-05-10', shift: 'Vespertino' })
    });
    const j = await res.json();
    console.log(JSON.stringify(j));
  } catch (e) { console.error(e); process.exit(1); }
})();
