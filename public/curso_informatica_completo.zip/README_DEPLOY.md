Deploy guide — Curso de Informática Básica

Passos rápidos para subir o código ao GitHub e fazer deploy do frontend no Vercel e do backend em um host para Node (Render/Railway).

1) GitHub
- Crie o repositório em https://github.com/new com nome `informaticabasica`.
- No seu projeto local execute:
```
git remote add origin https://github.com/SEU_USUARIO/informaticabasica.git
git push -u origin main
```

2) Vercel (frontend)
- Acesse https://vercel.com, clique em "New Project" e autorize o acesso ao GitHub.
- Selecione o repositório `informaticabasica`.
- Build Command: `npm run build`
- Output Directory: `dist`
- Adicione variáveis de ambiente (Settings → Environment Variables) se o frontend precisar de `API_URL`.
- Deploy.

Obs: O projeto contém um backend Express (`server.ts`). Vercel não é ideal para executar um processo Node persistente. Recomendo:
- Deploy do frontend no Vercel (estático).  
- Deploy do backend em Render / Railway / Fly.io / Heroku (serviço permanente).  

3) Deploy do backend (Render exemplo)
- Crie conta em https://render.com
- New → Web Service → Conecte ao repo GitHub → Start Command: `npm run start` → Environment: `node` → Add ENV vars se necessário.

4) Vídeos
- Não subir MP4s ao GitHub. Use YouTube (Unlisted), Vimeo, ou storage (S3 + CloudFront).  
- Se quiser, use o script `scripts/replace_video_paths.cjs` para gerar um arquivo com os vídeos atuais e substituir por URLs externas manualmente.

5) Depois de feito o push
- Me avise aqui que o repo está criado e com push — eu ajudo a configurar Vercel e preparar `database.json` para produção.

== Arquivo útil gerado ==
- `video_url_replacements.json`: lista das entradas de vídeo atuais com o campo `replaceWith` onde você deve colar as URLs públicas (YouTube/Vimeo).  
- Rode `node scripts/apply_video_urls.cjs` para aplicar as substituições em `data/database.json` automaticamente.

== Deploy recomendado (passo a passo resumido) ==
- Frontend: Vercel
	- Build command: `npm run build`
	- Output dir: `dist`
- Backend: Render (ou Railway)
	- Use Dockerfile (já incluído) ou Start Command: `npm run start`

