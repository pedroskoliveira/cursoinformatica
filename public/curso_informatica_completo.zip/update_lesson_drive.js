(async ()=>{
  try {
    const link = 'https://drive.google.com/file/d/12-lnS9rzgO9v5T4HsPt81T0L-zuxzZgD/view?usp=sharing';
    const body = {
      title: 'Dia 1: Anatomia do Computador & Hardware Essencial',
      subtitle: 'Video via Google Drive',
      videoUrl: link,
      videoType: 'mp4'
    };
    const res = await fetch('http://localhost:3000/api/course/day/1', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    const j = await res.json();
    console.log(JSON.stringify(j, null, 2));
  } catch (e) { console.error(e); process.exit(1); }
})();
