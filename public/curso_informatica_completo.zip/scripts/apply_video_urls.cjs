const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, '..', 'data', 'database.json');
const REPLACE_PATH = path.join(__dirname, '..', 'video_url_replacements.json');

function main() {
  if (!fs.existsSync(REPLACE_PATH)) {
    console.error('Missing', REPLACE_PATH);
    process.exit(2);
  }
  const replacements = JSON.parse(fs.readFileSync(REPLACE_PATH, 'utf8'));
  const db = JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));

  replacements.forEach((entry) => {
    const lesson = (db.lessons || []).find(l => l.id === entry.lessonId || l.day === entry.day);
    if (!lesson) return;
    const videos = lesson.videos || (lesson.videoUrl ? [{ url: lesson.videoUrl }] : []);
    entry.videos.forEach((v, idx) => {
      const newUrl = v.replaceWith;
      if (!newUrl || newUrl === 'PASTE_EXTERNAL_URL_HERE') return;
      if (videos[idx]) videos[idx].url = newUrl;
      else videos[idx] = { url: newUrl };
    });
    lesson.videos = videos;
    // remove legacy videoUrl if present
    if (lesson.videoUrl) delete lesson.videoUrl;
  });

  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
  console.log('Applied replacements to', DB_PATH);
}

main();
